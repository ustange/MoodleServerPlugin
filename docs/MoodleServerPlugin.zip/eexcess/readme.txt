copyright: bit media e-solutions GmbH, gerhard.doppler@bitmedia.cc
license: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or late
Block EEXCESS plugin for Moodle ======================= It is a tool that provides you recommendations from cultural and scientific databases in a Moodle environment (http://www.moodle.org) .
Instruction manual ======================= https://github.com/EEXCESS/moodle-block_eexcess/blob/master/README.md