window.console.log("I am javascript file loaded from php");
